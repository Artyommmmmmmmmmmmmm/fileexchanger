package com.example.myapplication.data;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.example.myapplication.data.ExprDao;
import com.example.myapplication.data.Expr;

@Database(entities = {Expr.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract ExprDao exprDao();

    private static AppDatabase INSTANCE;

    public static AppDatabase getDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(
                    context.getApplicationContext(),
                    AppDatabase.class,
                    "app_database"  // Имя файла БД
            ).build();
        }
        return INSTANCE;
    }
}