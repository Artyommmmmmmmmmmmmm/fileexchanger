package com.example.myapplication.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import com.example.myapplication.data.Expr;
import java.util.List;

@Dao
public interface ExprDao {

    @Query("SELECT * FROM expressions")
    List<Expr> getAllExprs();

    @Query("DELETE FROM expressions")  // замените на имя своей таблицы
    void deleteAll();

    @Insert
    void insertExpr(Expr expression);
}