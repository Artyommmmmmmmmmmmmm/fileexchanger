package com.example.myapplication;

public class ListItem {
    String expr;
    Double answer;
    public ListItem(String expr, Double answer) {
        this.expr = expr;
        this.answer = answer;
    }
    public String getExpr() {
        return expr;
    }
    public Double getAsnwer() {
        return answer;
    }
}
