package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.ExpressionParser;
import com.example.myapplication.data.AppDatabase;
import com.example.myapplication.data.Expr;
import com.google.android.material.navigation.NavigationView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView res;
    EditText expr;
    Button btn;
    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;
    Button btn5;
    Button btn6;
    Button btn7;
    Button btn8;
    Button btn9;
    Button btn10;
    Button btnplus;
    Button btnminus;
    Button btnequal;
    Button btnerase;
    Button btnamp;
    Button btndiv;
    Toolbar toolbar;
    LinearLayout navView;
    DrawerLayout drawer;
    RecyclerView listView;
    Button cleanse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        res = findViewById(R.id.res);
        expr = findViewById(R.id.expr);
        btn1 = findViewById(R.id.button1);
        btn2 = findViewById(R.id.button2);
        btn3 = findViewById(R.id.button3);
        btn4 = findViewById(R.id.button4);
        btn5 = findViewById(R.id.button5);
        btn6 = findViewById(R.id.button6);
        btn7 = findViewById(R.id.button7);
        btn8 = findViewById(R.id.button8);
        btn9 = findViewById(R.id.button9);
        btn10 = findViewById(R.id.button10);
        btnplus = findViewById(R.id.buttonplus);
        btnminus = findViewById(R.id.buttonminus);
        btnequal = findViewById(R.id.buttonequal);
        btnerase = findViewById(R.id.buttonerase);
        btnamp = findViewById(R.id.buttonamp);
        btndiv = findViewById(R.id.buttondiv);
        toolbar = findViewById(R.id.toolbar);
        navView = findViewById(R.id.nav_view);
        drawer = findViewById(R.id.drawer);
        listView = findViewById(R.id.listView);
        cleanse = findViewById(R.id.cleanse);
        var db = AppDatabase.getDatabase(this);

        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        listView = findViewById(R.id.listView);
        ArrayList<ListItem> items = new ArrayList<>();
        ItemAdapter adapter = new ItemAdapter(items);
        new Thread(() -> {
            for (var i : db.exprDao().getAllExprs()) {
                items.add(new ListItem(i.expression, i.answer));
            }
            runOnUiThread(() -> {
                adapter.setItems(items);
                adapter.notifyDataSetChanged();
            });
        }).start();
        listView.setLayoutManager(new LinearLayoutManager(this));
        listView.setAdapter(adapter);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "1";
                expr.setText(newExpr);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "2";
                expr.setText(newExpr);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "3";
                expr.setText(newExpr);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "4";
                expr.setText(newExpr);
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "5";
                expr.setText(newExpr);
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "6";
                expr.setText(newExpr);
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "7";
                expr.setText(newExpr);
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "8";
                expr.setText(newExpr);
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "9";
                expr.setText(newExpr);
            }
        });
        btn10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "0";
                expr.setText(newExpr);
            }
        });
        btnplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "+";
                expr.setText(newExpr);
            }
        });
        btnminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "-";
                expr.setText(newExpr);
            }
        });
        btnamp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "*";
                expr.setText(newExpr);
            }
        });
        btndiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                String newExpr = expression + "/";
                expr.setText(newExpr);
            }
        });
        btnerase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = expr.getText().toString();
                if (!expression.isEmpty()) {
                    String newExpr = expression.substring(0, expression.length() - 1);
                    expr.setText(newExpr);
                }

            }
        });
        btnequal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                var expression = expr.getText().toString();
                try {
                    double result = ExpressionParser.evaluate(expression);
                    new Thread(() -> {
                        Expr newexpr = new Expr();
                        newexpr.expression = expression;
                        newexpr.answer = result;
                        db.exprDao().insertExpr(newexpr);
                        items.clear();
                        for (var i : db.exprDao().getAllExprs()) {
                            items.add(new ListItem(i.expression, i.answer));
                        }
                        runOnUiThread(() -> {
                            adapter.setItems(items);
                            adapter.notifyDataSetChanged();
                        });
                    }).start();
                    res.setText(String.valueOf((double) result));
                } catch (Exception e) {
                    res.setText("Неверное выражение");
//                    throw new RuntimeException(e);
                }
            }
        });

        cleanse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(() -> {
                   db.exprDao().deleteAll();
                }).start();
                adapter.clear();
                adapter.notifyDataSetChanged();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.drawer), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}