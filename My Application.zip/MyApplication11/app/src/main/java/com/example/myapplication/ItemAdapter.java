package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.ListItem;
import com.example.myapplication.R;

import java.util.List;

// Адаптер наследуется от RecyclerView.Adapter<StudentAdapter.StudentViewHolder>
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    // Список данных
    private List<ListItem> itemList;

    // Конструктор адаптера
    public ItemAdapter(List<ListItem> itemList) {
        this.itemList = itemList;
    }

    // 1. Метод для создания нового ViewHolder (вызывается, когда системе нужен новый элемент)
    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // "Надуваем" разметку элемента списка
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        return new ItemViewHolder(itemView);
    }

    // 2. Метод для привязки данных к ViewHolder (вызывается для отображения данных в конкретной позиции)
    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        // Получаем объект студента для текущей позиции
        ListItem currentItem = itemList.get(position);
        // Передаем его в holder для отображения
        holder.bind(currentItem);
    }

    // 3. Метод, возвращающий общее количество элементов
    @Override
    public int getItemCount() {
        return itemList.size();
    }
    public void setItems(List<ListItem> newItems) {
        this.itemList = newItems;
    }

    public void clear() {
        this.itemList.clear();
    }
    // Внутренний статический класс ViewHolder
    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        // Здесь хранятся ссылки на элементы разметки
        private TextView exprItem;
        private TextView answerItem;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            // Инициализируем ссылки на View-элементы
            exprItem = itemView.findViewById(R.id.exprItem);
            answerItem = itemView.findViewById(R.id.answerItem);
        }

        // Метод для заполнения данными
        public void bind(@NonNull ListItem student) {
            exprItem.setText(student.getExpr());
            answerItem.setText(String.valueOf(student.getAsnwer()));
        }
    }
}