package com.example.myapplication;
import java.util.*;
import java.util.regex.*;

public class ExpressionParser {

    public static double evaluate(String expression) throws Exception {
        // Убираем пробелы
        expression = expression.replaceAll("\\s+", "");

        // Преобразуем в обратную польскую нотацию
        List<String> rpn = toRPN(expression);

        // Вычисляем RPN
        return evaluateRPN(rpn);
    }

    // Преобразование в RPN (алгоритм сортировочной станции)
    private static List<String> toRPN(String expr) throws Exception {
        List<String> output = new ArrayList<>();
        Stack<String> operators = new Stack<>();

        // Токенизация: числа (целые и дробные), операторы, скобки
        Pattern tokenPattern = Pattern.compile("(\\d+(?:\\.\\d+)?)|([+\\-*/()])");
        Matcher matcher = tokenPattern.matcher(expr);

        String lastToken = null;
        while (matcher.find()) {
            String token = matcher.group();

            if (token.matches("\\d+(?:\\.\\d+)?")) { // Число
                output.add(token);
            }
            else if (token.equals("(")) {
                operators.push(token);
            }
            else if (token.equals(")")) {
                while (!operators.isEmpty() && !operators.peek().equals("(")) {
                    output.add(operators.pop());
                }
                if (operators.isEmpty() || !operators.pop().equals("(")) {
                    throw new Exception("Mismatched parentheses");
                }
            }
            else { // Оператор + - * /
                // Обработка унарного минуса/плюса
                if ((token.equals("-") || token.equals("+")) &&
                        (lastToken == null || lastToken.equals("(") || isOperator(lastToken))) {
                    // Если это унарный минус - добавляем 0 перед ним
                    output.add("0");
                }

                while (!operators.isEmpty() &&
                        precedence(operators.peek()) >= precedence(token)) {
                    output.add(operators.pop());
                }
                operators.push(token);
            }
            lastToken = token;
        }

        while (!operators.isEmpty()) {
            String op = operators.pop();
            if (op.equals("(") || op.equals(")")) {
                throw new Exception("Mismatched parentheses");
            }
            output.add(op);
        }

        return output;
    }

    private static boolean isOperator(String token) {
        return token.matches("[+\\-*/]");
    }

    private static int precedence(String op) {
        switch (op) {
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            default:
                return 0;
        }
    }

    // Вычисление выражения в RPN
    private static double evaluateRPN(List<String> rpn) throws Exception {
        Stack<Double> stack = new Stack<>();

        for (String token : rpn) {
            if (token.matches("\\d+(?:\\.\\d+)?")) {
                stack.push(Double.parseDouble(token));
            }
            else { // Оператор
                if (stack.size() < 2) {
                    throw new Exception("Invalid expression");
                }
                double b = stack.pop();
                double a = stack.pop();
                switch (token) {
                    case "+": stack.push(a + b); break;
                    case "-": stack.push(a - b); break;
                    case "*": stack.push(a * b); break;
                    case "/":
                        if (b == 0) throw new ArithmeticException("Division by zero");
                        stack.push(a / b);
                        break;
                    default: throw new Exception("Unknown operator: " + token);
                }
            }
        }

        if (stack.size() != 1) {
            throw new Exception("Invalid expression");
        }
        return stack.pop();
    }
}
