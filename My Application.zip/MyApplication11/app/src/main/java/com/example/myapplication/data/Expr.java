package com.example.myapplication.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "expressions")
public class Expr {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String expression;
    public double answer;
}